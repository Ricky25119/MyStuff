param(
    [Parameter(Mandatory=$true)]
    [string]$gatewayKey
)

# Initialize log setting
$logLoc = "$env:SystemDrive\WindowsAzure\Logs\Plugins\Microsoft.Compute.CustomScriptExtension"
if (!(Test-Path $logLoc)) {
    New-Item -Path $logLoc -Type Directory -Force | Out-Null
}
$logPath = "$logLoc\gatewayInstall.log"

function Log-Time([string]$msg) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $msg" | Out-File $logPath -Append
}

function Throw-Error([string] $msg) {
    Log-Time "ERROR: $msg"
    throw $msg
}

function Download-MSI([string] $url, [string] $destination) {
    $maxRetries = 3
    $attempt = 0
    while ($attempt -lt $maxRetries) {
        try {
            Log-Time "Downloading MSI, attempt $($attempt+1)"
            if (Test-Path $destination) { Remove-Item $destination -Force }
            Start-BitsTransfer -Source $url -Destination $destination -ErrorAction Stop
            if (Test-Path $destination -and ((Get-Item $destination).Length -gt 10MB)) {
                Log-Time "MSI download succeeded: $destination"
                return
            } else {
                Log-Time "Downloaded MSI is missing or too small"
            }
        } catch {
            Log-Time "Download failed on attempt $($attempt+1): $($_.Exception.Message)"
        }
        $attempt++
        Start-Sleep -Seconds 10
    }
    Throw-Error "Failed to download MSI after $maxRetries attempts"
}

function Install-MSI([string] $msiPath) {
    Log-Time "Starting MSI installation: $msiPath"
    if (!(Test-Path $msiPath)) {
        Throw-Error "MSI file not found: $msiPath"
    }
    $msiLog = "$env:TEMP\shir_install.log"
    $arguments = "/i `"$msiPath`" INSTALLTYPE=AzureTemplate /quiet /norestart /l*v `"$msiLog`""
    $process = Start-Process -FilePath "msiexec.exe" -ArgumentList $arguments -Wait -PassThru
    if ($process.ExitCode -ne 0) {
        $logContent = Get-Content -Path $msiLog -Raw -ErrorAction SilentlyContinue
        Throw-Error "MSI install failed with exit code $($process.ExitCode). MSI log: $logContent"
    }
    Log-Time "MSI installation completed successfully"
    Start-Sleep -Seconds 30
}

function Get-Installed-DiacmdPath() {
    $regPath = "HKLM:\Software\Microsoft\DataTransfer\DataManagementGateway\ConfigurationManager"
    try {
        $filePath = Get-ItemProperty -Path $regPath -Name "DiacmdPath" -ErrorAction Stop | Select-Object -ExpandProperty DiacmdPath
        if ([string]::IsNullOrEmpty($filePath)) {
            Throw-Error "DiacmdPath registry value is empty"
        }
        Log-Time "Found DiacmdPath: $filePath"
        return $filePath
    } catch {
        Throw-Error "Failed to read DiacmdPath from registry: $($_.Exception.Message)"
    }
}

function Register-Gateway([string] $instanceKey) {
    Log-Time "Starting SHIR registration"
    $diacmd = Get-Installed-DiacmdPath
    $exitCode1 = Start-Process -FilePath $diacmd -ArgumentList "-era 8050" -Wait -PassThru
    if ($exitCode1.ExitCode -ne 0) {
        Throw-Error "Failed to run -era command, exit code: $($exitCode1.ExitCode)"
    }
    $exitCode2 = Start-Process -FilePath $diacmd -ArgumentList "-k $instanceKey" -Wait -PassThru
    if ($exitCode2.ExitCode -ne 0) {
        Throw-Error "Failed to run -k registration command, exit code: $($exitCode2.ExitCode)"
    }
    Log-Time "SHIR registration completed successfully"
}

# Main
try {
    Log-Time "Script execution started"
    $uri = "https://download.microsoft.com/download/e/4/7/e4771905-1079-445b-8bf9-8a1a075d8a10/IntegrationRuntime_5.52.9229.1.msi"
    $gwPath = "$env:TEMP\IntegrationRuntime_5.52.msi"

    Log-Time "Downloading MSI from $uri"
    Download-MSI $uri $gwPath

    Log-Time "Installing MSI"
    Install-MSI $gwPath

    Log-Time "Registering Gateway"
    Register-Gateway $gatewayKey

    Log-Time "Script execution finished successfully"
} catch {
    Log-Time "Script execution failed: $($_.Exception.Message)"
    throw
}
